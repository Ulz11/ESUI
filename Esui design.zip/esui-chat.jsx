const { useState, useEffect, useRef, useCallback } = React;

// ─── Mock data ───────────────────────────────────────────────────────────────

const CONVS = [
  { id:'c1', title:'Theory of knowledge — first principles',   preview:'revisit the Gettier problem',            ts:'2h',  dot:false },
  { id:'c2', title:'ESUI launch planning',                     preview:'biggest risk is scope creep',             ts:'1d',  dot:true  },
  { id:'c3', title:'Weekend plans',                            preview:'maybe we could watch something together', ts:'3d',  dot:false },
  { id:'c4', title:'Reading list: Wittgenstein',               preview:'Tractatus first, then Investigations',    ts:'5d',  dot:false },
];

const SEED_MSGS = [
  { id:'m1', role:'user', user:'esui',
    text:`I've been thinking about the Gettier problem and whether it actually defeats the JTB account of knowledge. What's your reading?`,
    mode:null, ts:'10:24' },
  { id:'m2', role:'ai', mode:'ulzii',
    text:`The Gettier problem is genuinely damaging to JTB, but the most interesting response isn't to patch the definition — it's to ask whether the project of defining knowledge propositionally was ever well-motivated.\n\nGettier's cases work by constructing situations where justified true belief seems *accidental*. The agent doesn't lack knowledge because their belief is false or unjustified; the truth and the justification are related in the wrong way — causally disconnected.\n\nThis points toward reliabilist and causal theories: knowledge may require not just JTB but the right kind of *process* linking belief to truth.`,
    ts:'10:25' },
  { id:'m3', role:'user', user:'esui',
    text:`So reliabilism is the move? Goldman?`,
    mode:null, ts:'10:27' },
  { id:'m4', role:'ai', mode:'ulzii',
    text:`Goldman is the canonical starting point. His 1967 paper "A Causal Theory of Knowing" is essentially the first systematic response to Gettier.\n\nThe core move: S knows that p iff there is an appropriate causal connection between the fact that p and S's belief that p. This handles the Gettier cases neatly — in those cases, the causal chain is broken or deviant.\n\nBut reliabilism has its own problems. The generality problem: what counts as the relevant process-type for assessing reliability? And there are demon-world cases where a perfectly reliable cognitive process would still seem to deliver knowledge even if it were, counterfactually, unreliable.`,
    ts:'10:28' },
];

const VAULT_SUGGESTION = {
  title: 'Gettier & the limits of JTB',
  content_md: 'Gettier (1963) shows JTB is insufficient for knowledge — cases exist where an agent has justified true belief yet clearly lacks knowledge. The truth and the justification are causally disconnected. Motivates reliabilism (Goldman 1967).',
  tags: ['epistemology','philosophy','knowledge'],
};

const STREAM_CHUNKS = [
  `That's a genuinely hard question. `,
  `The demon-world objection cuts deep because it isolates *subjective* from *objective* reliability.\n\n`,
  `One response: distinguish between strong and weak knowledge. `,
  `In the demon world, you might have weak knowledge — internally justified, well-functioning processes — but not strong knowledge, which requires world-tracking. `,
  `This is roughly the internalist / externalist divide.\n\n`,
  `The more interesting move, I think, is to ask whether we need a single unified concept at all. `,
  `Perhaps "knows" is a family-resemblance term — we should stop looking for necessary and sufficient conditions `,
  `and start mapping the *uses* of the concept across contexts. That's the Wittgensteinian dissolution.`,
];

// ─── Components ──────────────────────────────────────────────────────────────

function ChatWidget({ mode, setMode }) {
  const [activeConv, setActiveConv] = useState(CONVS[0]);
  const [msgs, setMsgs]             = useState(SEED_MSGS);
  const [input, setInput]           = useState('');
  const [streaming, setStreaming]   = useState(false);
  const [streamText, setStreamText] = useState('');
  const [pinned, setPinned]         = useState(false);
  const [savedVault, setSavedVault] = useState(false);
  const [presence]                  = useState(true); // Badrushk online
  const endRef   = useRef(null);
  const inputRef = useRef(null);
  const timerRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, streamText]);

  const send = useCallback(() => {
    if (!input.trim() || streaming) return;
    const userMsg = {
      id: `u${Date.now()}`, role:'user', user:'esui',
      text: input.trim(), mode:null,
      ts: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
    };
    setMsgs(p => [...p, userMsg]);
    setInput('');

    setTimeout(() => {
      setStreaming(true);
      setStreamText('');
      let full = '';
      let ci = 0;
      let ci2 = 0;
      const chunks = STREAM_CHUNKS;

      const tick = () => {
        if (ci >= chunks.length) {
          setStreaming(false);
          const aiMsg = {
            id: `a${Date.now()}`, role:'ai', mode,
            text: full, ts: new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
            vaultSuggestion: true,
          };
          setMsgs(p => [...p, aiMsg]);
          setStreamText('');
          return;
        }
        const chunk = chunks[ci];
        if (ci2 < chunk.length) {
          full += chunk[ci2];
          setStreamText(full);
          ci2++;
          timerRef.current = setTimeout(tick, 14);
        } else {
          ci++;
          ci2 = 0;
          timerRef.current = setTimeout(tick, 40);
        }
      };
      timerRef.current = setTimeout(tick, 700);
    }, 0);
  }, [input, streaming, mode]);

  const stopStream = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setStreaming(false);
    if (streamText) {
      setMsgs(p => [...p, { id:`a${Date.now()}`, role:'ai', mode, text:streamText, ts:'now' }]);
    }
    setStreamText('');
  };

  const modeColor  = mode === 'ulzii' ? 'var(--sky)'        : 'var(--forest)';
  const modeBg     = mode === 'ulzii' ? 'var(--sky-bg)'     : 'var(--forest-bg)';
  const modeBorder = mode === 'ulzii' ? 'var(--sky-border)' : 'var(--forest-border)';

  return (
    <div style={cS.container}>
      {/* ── Sidebar ── */}
      <div style={cS.sidebar}>
        <div style={cS.sidebarHead}>
          <span style={cS.sidebarLabel}>conversations</span>
          <button style={cS.iconBtn} title="New conversation">
            <PlusIcon />
          </button>
        </div>
        <div style={cS.convList}>
          {CONVS.map(c => (
            <button
              key={c.id}
              style={{ ...cS.convRow, ...(activeConv.id === c.id ? cS.convRowActive : {}) }}
              onClick={() => setActiveConv(c)}
            >
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
                {c.dot && <span style={{ width:5, height:5, borderRadius:'50%', background:modeColor, flexShrink:0 }} />}
                <span style={{ fontSize:13, fontWeight: c.dot?500:400, color:'var(--navy)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', flex:1 }}>{c.title}</span>
              </div>
              <div style={{ display:'flex', justifyContent:'space-between', gap:8 }}>
                <span style={{ fontSize:11.5, color:'var(--navy-35)', fontFamily:'var(--serif)', fontStyle:'italic', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', flex:1 }}>{c.preview}</span>
                <span style={{ fontSize:11, color:'var(--navy-35)', flexShrink:0 }}>{c.ts}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ── Main ── */}
      <div style={cS.main}>
        {/* Pinned context */}
        <div style={cS.pinnedBar}>
          <button style={cS.pinnedBtn} onClick={() => setPinned(!pinned)}>
            <PinIcon active={pinned} />
            <span style={{ flex:1, textAlign:'left' }}>working on the ESUI launch — he's thinking of you</span>
            <ChevronIcon up={pinned} />
          </button>
          {pinned && (
            <div style={cS.pinnedBody} className="anim-fade-up">
              <p style={{ fontSize:13, fontFamily:'var(--serif)', color:'var(--navy-60)', lineHeight:1.7 }}>
                Building ESUI — a private AI workspace for two. Launch is end of month. Key surfaces: Chat, Vault, Exam, Signals, Together Photos.
              </p>
            </div>
          )}
        </div>

        {/* Presence */}
        <div style={cS.presenceBar}>
          <span style={{ width:6, height:6, borderRadius:'50%', background: presence ? '#4ade80' : 'var(--navy-35)', flexShrink:0, boxShadow: presence ? '0 0 0 2px rgba(74,222,128,.2)' : 'none' }} />
          <span style={{ fontSize:11.5, color:'var(--navy-35)' }}>Badrushk {presence ? 'is here' : 'is away'}</span>
        </div>

        {/* Messages */}
        <div style={cS.messages}>
          {msgs.map(msg => (
            msg.role === 'user'
              ? <UserBubble key={msg.id} msg={msg} />
              : <AIBubble   key={msg.id} msg={msg} mode={msg.mode} savedVault={savedVault} onSaveVault={() => setSavedVault(true)} />
          ))}

          {streaming && (
            <div style={{ ...cS.aiMsg, animation:'fadeUp .15s ease' }}>
              <span style={{ ...cS.aiLabel, color: modeColor }}>
                {mode === 'ulzii' ? 'Ulzii' : 'Obama'}
              </span>
              <p style={cS.aiText}>
                {streamText.split('\n\n').map((p, i, arr) => (
                  <React.Fragment key={i}>
                    {p}
                    {i < arr.length - 1 && <><br/><br/></>}
                  </React.Fragment>
                ))}
                <span style={{ display:'inline-block', width:1.5, height:'1em', background:modeColor, verticalAlign:'text-bottom', marginLeft:1, animation:'blink 1s ease infinite' }} />
              </p>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Composer */}
        <div style={cS.composer}>
          <div style={cS.composerTop}>
            <div style={{ ...cS.modePill, borderColor: modeBorder }}>
              <button
                style={{ ...cS.modeBtn, ...(mode === 'ulzii' ? { background:'var(--sky-bg)', color:'var(--sky)' } : {}) }}
                onClick={() => setMode('ulzii')}
              >Ulzii</button>
              <button
                style={{ ...cS.modeBtn, ...(mode === 'obama' ? { background:'var(--forest-bg)', color:'var(--forest)' } : {}) }}
                onClick={() => setMode('obama')}
              >Obama</button>
            </div>
            <span style={{ fontSize:11, color:'var(--navy-35)', fontFamily:'var(--serif)', fontStyle:'italic' }}>
              {mode === 'ulzii' ? 'contemplative · first principles' : 'decisive · founder\'s lens'}
            </span>
          </div>
          <div style={cS.inputRow}>
            <button style={cS.attachBtn} title="Attach file"><AttachIcon /></button>
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="ask anything — Ulzii or Obama will respond"
              style={{ ...cS.textarea, fontFamily:'var(--serif)' }}
              rows={1}
              disabled={streaming}
            />
            {streaming
              ? <button style={{ ...cS.sendBtn, background:'var(--navy-15)' }} onClick={stopStream} title="Stop"><StopIcon /></button>
              : <button
                  style={{ ...cS.sendBtn, background: input.trim() ? modeColor : 'var(--vanilla-border)', cursor: input.trim() ? 'pointer' : 'default' }}
                  onClick={send} disabled={!input.trim()}
                ><SendIcon /></button>
            }
          </div>
        </div>
      </div>
    </div>
  );
}

function UserBubble({ msg }) {
  return (
    <div style={cS.userMsg}>
      <p style={cS.userText}>{msg.text}</p>
      <span style={cS.ts}>{msg.ts}</span>
    </div>
  );
}

function AIBubble({ msg, mode, savedVault, onSaveVault }) {
  const modeColor = msg.mode === 'ulzii' ? 'var(--sky)' : msg.mode === 'obama' ? 'var(--forest)' : 'var(--navy-60)';
  const label     = msg.mode === 'ulzii' ? 'Ulzii' : msg.mode === 'obama' ? 'Obama' : 'AI';

  return (
    <div style={cS.aiMsg} className="anim-fade-up">
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ ...cS.aiLabel, color:modeColor }}>{label}</span>
        <span style={cS.ts}>{msg.ts}</span>
      </div>
      <p style={cS.aiText}>
        {msg.text.split('\n\n').map((p, i, arr) => (
          <React.Fragment key={i}>
            {p}
            {i < arr.length - 1 && <><br/><br/></>}
          </React.Fragment>
        ))}
      </p>
      {msg.vaultSuggestion && (
        <div style={cS.vaultCard} className="anim-fade-up">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
            <span style={{ fontSize:11, fontWeight:600, letterSpacing:'.06em', textTransform:'uppercase', color:'var(--sky)' }}>vault suggestion</span>
            {savedVault && <span style={{ fontSize:11, color:'var(--forest)' }}>✓ saved</span>}
          </div>
          <p style={{ fontSize:13, fontWeight:500, fontFamily:'var(--serif)', color:'var(--navy)', marginBottom:4 }}>{VAULT_SUGGESTION.title}</p>
          <p style={{ fontSize:12.5, fontFamily:'var(--serif)', color:'var(--navy-60)', lineHeight:1.6, marginBottom:8 }}>{VAULT_SUGGESTION.content_md}</p>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:10 }}>
            {VAULT_SUGGESTION.tags.map(t => <span key={t} style={cS.tag}>{t}</span>)}
          </div>
          {!savedVault && (
            <div style={{ display:'flex', gap:10 }}>
              <button style={cS.vaultSave} onClick={onSaveVault}>save to vault</button>
              <button style={cS.vaultDismiss}>dismiss</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Icons ───────────────────────────────────────────────────────────────────
const PlusIcon    = () => <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M6.5 1.5v10M1.5 6.5h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>;
const PinIcon     = ({ active }) => <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 1.5L7.5 4.5H10.5L8.25 6.75L9 9.75L6 8.25L3 9.75L3.75 6.75L1.5 4.5H4.5L6 1.5Z" stroke="currentColor" strokeWidth="1" strokeLinejoin="round" fill={active?'currentColor':'none'}/></svg>;
const ChevronIcon = ({ up }) => <svg width="10" height="10" viewBox="0 0 10 10" fill="none" style={{ transform: up?'rotate(180deg)':'none', transition:'transform .15s' }}><path d="M2 4l3 3 3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const AttachIcon  = () => <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M3 7.5V4a4 4 0 118 0v7a2.5 2.5 0 01-5 0V5a1 1 0 012 0v6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const StopIcon    = () => <svg width="11" height="11" viewBox="0 0 11 11" fill="none"><rect x="1.5" y="1.5" width="8" height="8" rx="1.5" fill="currentColor"/></svg>;
const SendIcon    = () => <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M11 6.5L2 2l2.5 4.5L2 11z" fill="white"/></svg>;

// ─── Styles ──────────────────────────────────────────────────────────────────
const cS = {
  container: { display:'flex', height:'100%', overflow:'hidden' },
  sidebar:   { width:260, flexShrink:0, borderRight:'1px solid var(--vanilla-border)', display:'flex', flexDirection:'column', background:'var(--vanilla)' },
  sidebarHead: { padding:'18px 14px 12px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid var(--vanilla-border)' },
  sidebarLabel: { fontSize:10.5, fontWeight:600, letterSpacing:'.08em', textTransform:'uppercase', color:'var(--navy-35)' },
  iconBtn:   { width:24, height:24, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--navy-60)', borderRadius:'var(--rs)' },
  convList:  { flex:1, overflowY:'auto', padding:'6px 6px' },
  convRow:   { width:'100%', textAlign:'left', padding:'9px 8px', borderRadius:'var(--r)', cursor:'pointer', display:'block', marginBottom:1 },
  convRowActive: { background:'var(--vanilla-2)' },
  main:      { flex:1, display:'flex', flexDirection:'column', overflow:'hidden', background:'var(--white)' },
  pinnedBar: { borderBottom:'1px solid var(--vanilla-border)' },
  pinnedBtn: { width:'100%', textAlign:'left', display:'flex', alignItems:'center', gap:7, padding:'9px 18px', color:'var(--navy-60)', fontSize:12, cursor:'pointer' },
  pinnedBody: { padding:'6px 18px 12px', borderTop:'1px solid var(--vanilla-border)' },
  presenceBar: { display:'flex', alignItems:'center', gap:6, padding:'6px 18px', borderBottom:'1px solid var(--vanilla-border)' },
  messages:  { flex:1, overflowY:'auto', padding:'28px 44px', display:'flex', flexDirection:'column', gap:26 },
  userMsg:   { alignSelf:'flex-end', maxWidth:540, display:'flex', flexDirection:'column', alignItems:'flex-end', gap:4 },
  userText:  { background:'var(--vanilla)', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', padding:'10px 14px', fontSize:14, lineHeight:1.65, fontFamily:'var(--serif)', color:'var(--navy)', whiteSpace:'pre-wrap', textWrap:'pretty' },
  aiMsg:     { alignSelf:'flex-start', maxWidth:660, display:'flex', flexDirection:'column', gap:7 },
  aiLabel:   { fontSize:12, fontWeight:500, fontStyle:'italic', fontFamily:'var(--serif)' },
  aiText:    { fontSize:14.5, lineHeight:1.78, fontFamily:'var(--serif)', fontWeight:300, color:'var(--navy)', textWrap:'pretty' },
  ts:        { fontSize:11, color:'var(--navy-35)' },
  vaultCard: { background:'var(--vanilla)', border:'1px solid var(--sky-border)', borderRadius:'var(--r)', padding:'12px 14px', marginTop:4 },
  tag:       { fontSize:11, color:'var(--navy-35)', padding:'2px 7px', border:'1px solid var(--vanilla-border)', borderRadius:10 },
  vaultSave: { fontSize:12.5, color:'var(--sky)', cursor:'pointer', background:'none', border:'none', fontWeight:500, padding:0 },
  vaultDismiss: { fontSize:12.5, color:'var(--navy-35)', cursor:'pointer', background:'none', border:'none', padding:0, fontStyle:'italic', fontFamily:'var(--serif)' },
  composer:  { borderTop:'1px solid var(--vanilla-border)', padding:'12px 18px 16px', background:'var(--white)', flexShrink:0 },
  composerTop: { display:'flex', alignItems:'center', gap:10, marginBottom:10 },
  modePill:  { display:'flex', padding:2, gap:2, borderRadius:20, border:'1px solid', background:'var(--vanilla)' },
  modeBtn:   { padding:'3px 11px', borderRadius:16, fontSize:12, fontWeight:500, color:'var(--navy-60)', cursor:'pointer', transition:'all .12s' },
  inputRow:  { display:'flex', alignItems:'flex-end', gap:8, border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', padding:'7px 8px 7px 10px', background:'var(--vanilla)' },
  attachBtn: { color:'var(--navy-35)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:2 },
  textarea:  { flex:1, fontSize:14, lineHeight:1.6, resize:'none', background:'transparent', maxHeight:120, overflow:'auto', color:'var(--navy)' },
  sendBtn:   { width:30, height:30, borderRadius:'var(--rs)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, transition:'background .12s' },
};

Object.assign(window, { ChatWidget });
