const { useState } = React;

function App() {
  const [authed, setAuthed] = useState(false);
  const [mode, setMode]     = useState('ulzii');

  if (!authed) return <LoginPage onLogin={() => setAuthed(true)} />;
  return <AppShell mode={mode} setMode={setMode} />;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
