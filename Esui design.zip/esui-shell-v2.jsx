const { useState, useEffect } = React;

function AppShellV2({ mode, setMode }) {
  const [route, setRoute]     = useState('home');
  const [settings, setSettings] = useState(false);
  const [theme, setTheme]     = useState('light');
  const [promptOn, setPromptOn] = useState(true);
  const [prevRoute, setPrevRoute] = useState(null);

  const navigate = (r) => {
    setPrevRoute(route);
    setRoute(r);
  };

  const darkVars = theme === 'dark' ? {
    '--page':    '#161824',
    '--surface': '#1d2035',
    '--border':  '#2a2e48',
    '--navy':    '#e8e2d8',
    '--navy-70': 'rgba(232,226,216,.70)',
    '--navy-60': 'rgba(232,226,216,.60)',
    '--navy-45': 'rgba(232,226,216,.45)',
    '--navy-35': 'rgba(232,226,216,.35)',
    '--navy-20': 'rgba(232,226,216,.20)',
    '--navy-15': 'rgba(232,226,216,.15)',
    '--navy-10': 'rgba(232,226,216,.10)',
    '--navy-08': 'rgba(232,226,216,.08)',
    '--white':   '#1d2035',
    '--vanilla': '#1d2035',
    '--vanilla-2':      '#242739',
    '--vanilla-border': '#2a2e48',
    '--sky-light':   'rgba(91,154,184,.18)',
    '--sky-bg':      'rgba(91,154,184,.15)',
    '--sky-border':  'rgba(91,154,184,.35)',
    '--sky-deep':    '#7ab5cd',
    '--forest-light':'rgba(62,111,84,.18)',
    '--forest-bg':   'rgba(62,111,84,.15)',
    '--forest-border':'rgba(62,111,84,.35)',
    '--indigo-light':'rgba(46,51,96,.35)',
    '--amber-light': 'rgba(140,107,58,.25)',
    '--rose-light':  'rgba(176,80,104,.25)',
    '--shadow-card':  '0 1px 3px rgba(0,0,0,.25), 0 4px 16px rgba(0,0,0,.35)',
    '--shadow-hover': '0 2px 8px rgba(0,0,0,.30), 0 12px 40px rgba(0,0,0,.45)',
  } : {};

  return (
    <div style={{ ...shV.root, ...darkVars }}>
      <TopNav
        route={route}
        onNavigate={navigate}
        mode={mode}
        setMode={setMode}
        onSettings={() => setSettings(true)}
      />

      <div style={shV.main}>
        {route === 'home'     && <BentoHome onNavigate={navigate} mode={mode} />}
        {route === 'chat'     && <WidgetWrap key="chat">    <ChatWidget    mode={mode} setMode={setMode} /></WidgetWrap>}
        {route === 'vault'    && <WidgetWrap key="vault">   <VaultWidget   /></WidgetWrap>}
        {route === 'exam'     && <WidgetWrap key="exam">    <ExamWidget    /></WidgetWrap>}
        {route === 'signals'  && <WidgetWrap key="signals"> <SignalsWidget /></WidgetWrap>}
        {route === 'together' && <WidgetWrap key="together"><TogetherWidget /></WidgetWrap>}
      </div>

      {settings && (
        <SettingsDrawer
          onClose={() => setSettings(false)}
          mode={mode} setMode={setMode}
          theme={theme} setTheme={setTheme}
        />
      )}

      {route !== 'together' && route !== 'exam' && promptOn && (
        <TogetherPromptCard visible={true} onDismiss={() => setPromptOn(false)} />
      )}
    </div>
  );
}

// Wrapper that adds a fade-up entrance
function WidgetWrap({ children }) {
  return (
    <div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column', animation:'fadeUp .2s ease both' }}>
      {children}
    </div>
  );
}

const shV = {
  root: { width:'100vw', height:'100vh', display:'flex', flexDirection:'column', overflow:'hidden', background:'var(--page)' },
  main: { flex:1, overflow:'hidden', display:'flex', flexDirection:'column' },
};

Object.assign(window, { AppShellV2 });
