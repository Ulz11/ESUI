const { useState } = React;

// ─── Data ────────────────────────────────────────────────────────────────────

const MEMORIES = [
  { id:'m1', text:'Studying epistemology and philosophy of mind this semester',            cat:'academic',   salience:.95, src:'from chat',  used:'2h ago'  },
  { id:'m2', text:'Long-distance relationship with Badrushk; Together Photos is meaningful',cat:'personal',  salience:.93, src:'inferred',   used:'1d ago'  },
  { id:'m3', text:'Building ESUI — end-of-month launch target',                           cat:'work',       salience:.88, src:'from chat',  used:'3h ago'  },
  { id:'m4', text:'Prefers Ulzii for philosophical work, Obama for product decisions',    cat:'preference', salience:.85, src:'inferred',   used:'1d ago'  },
  { id:'m5', text:'Reads philosophy in Arabic and English',                               cat:'academic',   salience:.78, src:'manual',     used:'5d ago'  },
  { id:'m6', text:'Morning for deep work, evening for reading',                           cat:'preference', salience:.72, src:'inferred',   used:'1w ago'  },
  { id:'m7', text:'Interested in Chinese philosophy — especially Wang Yangming and Zhuangzi', cat:'academic', salience:.70, src:'from chat', used:'4d ago' },
];

const CAT_COL = { academic:'#5b9ab8', personal:'#c0534d', work:'#3e6f54', preference:'#8b6fba' };

const USAGE = [
  {d:'Mon',v:.12},{d:'Tue',v:.08},{d:'Wed',v:.21},{d:'Thu',v:.17},{d:'Fri',v:.09},{d:'Sat',v:.34},{d:'Sun',v:.15},
];

// ─── SettingsDrawer ───────────────────────────────────────────────────────────

function SettingsDrawer({ onClose, mode, setMode, theme, setTheme }) {
  const [tab, setTab]         = useState('profile');
  const [mems, setMems]       = useState(MEMORIES);
  const [memQ, setMemQ]       = useState('');
  const [fading, setFading]   = useState([]);

  const forget = (id) => {
    setFading(p => [...p, id]);
    setTimeout(() => setMems(p => p.filter(m => m.id !== id)), 380);
  };

  const filtered = mems.filter(m =>
    !memQ || m.text.toLowerCase().includes(memQ.toLowerCase()) || m.cat.includes(memQ.toLowerCase())
  );

  const maxV = Math.max(...USAGE.map(u => u.v));

  return (
    <div style={stS.overlay} onClick={onClose}>
      <div style={stS.drawer} onClick={e => e.stopPropagation()} className="anim-slide-r">

        <div style={stS.head}>
          <h2 style={stS.title}>Settings</h2>
          <button style={stS.xBtn} onClick={onClose}>
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M3.5 3.5l8 8M11.5 3.5l-8 8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
          </button>
        </div>

        <div style={stS.tabs}>
          {[['profile','Profile'],['memory','Memory'],['usage','Usage'],['theme','Theme']].map(([id,label]) => (
            <button key={id} style={{ ...stS.tab, ...(tab===id ? stS.tabActive : {}) }} onClick={() => setTab(id)}>{label}</button>
          ))}
        </div>

        <div style={stS.body}>
          {/* ── Profile ── */}
          {tab === 'profile' && (
            <div style={stS.section}>
              <div style={stS.avatarRow}>
                <div style={stS.avatar}>E</div>
                <div>
                  <p style={{ fontSize:15, fontWeight:500, fontFamily:'var(--serif)', marginBottom:2 }}>Esui</p>
                  <p style={{ fontSize:12, color:'var(--navy-60)' }}>esui@workspace.private</p>
                </div>
              </div>
              <Field label="Display name"><input defaultValue="Esui" style={stS.input} /></Field>
              <Field label="Timezone"><input defaultValue="Asia/Ulaanbaatar" style={stS.input} /></Field>
              <Field label="Default mode">
                <div style={{ display:'flex', gap:8 }}>
                  {[['ulzii','Ulzii','var(--sky)','var(--sky-bg)','var(--sky-border)'],['obama','Obama','var(--forest)','var(--forest-bg)','var(--forest-border)']].map(([id,label,col,bg,bord]) => (
                    <button key={id}
                      style={{ padding:'5px 16px', borderRadius:20, border:`1.5px solid ${mode===id?col:'var(--vanilla-border)'}`, background:mode===id?bg:'none', color:mode===id?col:'var(--navy-60)', fontSize:13, fontWeight:500, cursor:'pointer', transition:'all .12s' }}
                      onClick={() => setMode(id)}
                    >{label}</button>
                  ))}
                </div>
              </Field>
            </div>
          )}

          {/* ── Memory ── */}
          {tab === 'memory' && (
            <div style={stS.section}>
              <p style={stS.memIntro}>what the AI knows about you — you decide what stays</p>
              <div style={stS.memSearch}>
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" style={{ color:'var(--navy-35)', flexShrink:0 }}><circle cx="6" cy="6" r="4" stroke="currentColor" strokeWidth="1.3"/><path d="M9 9l2.5 2.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
                <input value={memQ} onChange={e => setMemQ(e.target.value)} placeholder="search memories…" style={{ flex:1, fontSize:13, background:'none', border:'none', outline:'none' }} />
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {filtered.map(m => (
                  <div key={m.id} style={{ ...stS.memRow, opacity:fading.includes(m.id)?.0:1, transform:fading.includes(m.id)?'translateX(6px)':'none', transition:'all .35s ease' }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <p style={{ fontSize:13, fontFamily:'var(--serif)', color:'var(--navy)', lineHeight:1.5, marginBottom:5 }}>{m.text}</p>
                      <div style={{ display:'flex', alignItems:'center', gap:7, flexWrap:'wrap' }}>
                        <span style={{ fontSize:10, fontWeight:500, padding:'2px 6px', borderRadius:8, background:(CAT_COL[m.cat]||'#888')+'18', color:CAT_COL[m.cat]||'#888' }}>{m.cat}</span>
                        <span style={{ fontSize:10.5, color:'var(--navy-35)' }}>{m.src}</span>
                        <div style={{ width:28, height:2.5, background:'var(--vanilla-border)', borderRadius:2, overflow:'hidden', marginLeft:'auto' }}>
                          <div style={{ height:'100%', width:`${m.salience*100}%`, background:CAT_COL[m.cat]||'#888', borderRadius:2 }} />
                        </div>
                        <span style={{ fontSize:10.5, color:'var(--navy-35)' }}>{m.used}</span>
                      </div>
                    </div>
                    <button style={stS.forgetBtn} onClick={() => forget(m.id)}>forget</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Usage ── */}
          {tab === 'usage' && (
            <div style={stS.section}>
              <div style={stS.usageTop}>
                <Stat n="$0.34" l="today" />
                <Stat n="$2.00" l="daily cap" />
                <Stat n="$5.12" l="this month" />
              </div>
              <p style={stS.fieldLabel}>7-day breakdown</p>
              <div style={{ display:'flex', gap:7, alignItems:'flex-end', height:72 }}>
                {USAGE.map(u => (
                  <div key={u.d} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
                    <div style={{ width:'100%', height:`${(u.v/maxV)*54}px`, background:'var(--sky)', borderRadius:'3px 3px 0 0', opacity:.65, minHeight:3 }} />
                    <span style={{ fontSize:10, color:'var(--navy-35)' }}>{u.d}</span>
                  </div>
                ))}
              </div>
              <p style={{ fontSize:11.5, color:'var(--navy-35)', fontFamily:'var(--serif)', fontStyle:'italic', marginTop:6 }}>daily cap resets at midnight UTC</p>
            </div>
          )}

          {/* ── Theme ── */}
          {tab === 'theme' && (
            <div style={stS.section}>
              <Field label="Appearance">
                <div style={{ display:'flex', gap:8 }}>
                  {[['light','Light'],['dark','Dark'],['system','System']].map(([id,label]) => (
                    <button key={id}
                      style={{ padding:'5px 16px', borderRadius:20, border:`1.5px solid ${theme===id?'var(--navy)':'var(--vanilla-border)'}`, background:theme===id?'var(--navy)':'none', color:theme===id?'var(--vanilla)':'var(--navy-60)', fontSize:13, fontWeight:500, cursor:'pointer', transition:'all .12s' }}
                      onClick={() => setTheme(id)}
                    >{label}</button>
                  ))}
                </div>
              </Field>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const Field = ({ label, children }) => (
  <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
    <span style={stS.fieldLabel}>{label}</span>
    {children}
  </div>
);

const Stat = ({ n, l }) => (
  <div>
    <p style={{ fontSize:26, fontWeight:300, fontFamily:'var(--serif)', color:'var(--navy)', lineHeight:1 }}>{n}</p>
    <p style={{ fontSize:11.5, color:'var(--navy-35)', marginTop:3 }}>{l}</p>
  </div>
);

// ─── Styles ──────────────────────────────────────────────────────────────────

const stS = {
  overlay: { position:'fixed', inset:0, background:'rgba(28,31,46,.35)', backdropFilter:'blur(3px)', zIndex:200, display:'flex', justifyContent:'flex-end' },
  drawer:  { width:420, height:'100%', background:'var(--white)', display:'flex', flexDirection:'column', overflow:'hidden', borderLeft:'1px solid var(--vanilla-border)' },
  head:    { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'18px 22px', borderBottom:'1px solid var(--vanilla-border)', flexShrink:0 },
  title:   { fontSize:17, fontWeight:300, fontFamily:'var(--serif)' },
  xBtn:    { width:27, height:27, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--navy-60)', cursor:'pointer', borderRadius:'var(--rs)' },
  tabs:    { display:'flex', padding:'0 14px', borderBottom:'1px solid var(--vanilla-border)', flexShrink:0 },
  tab:     { padding:'9px 11px', fontSize:12.5, fontWeight:500, color:'var(--navy-60)', cursor:'pointer', background:'none', border:'none', borderBottom:'2px solid transparent' },
  tabActive:{ color:'var(--navy)', borderBottom:'2px solid var(--navy)' },
  body:    { flex:1, overflowY:'auto' },
  section: { padding:'18px 22px', display:'flex', flexDirection:'column', gap:16 },
  avatarRow:{ display:'flex', alignItems:'center', gap:12, marginBottom:4 },
  avatar:  { width:42, height:42, borderRadius:'50%', background:'var(--sky-bg)', color:'var(--sky)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:17, fontFamily:'var(--serif)', border:'1.5px solid var(--sky-border)', flexShrink:0 },
  input:   { padding:'8px 11px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--rs)', fontSize:13.5, fontFamily:'var(--serif)', color:'var(--navy)', background:'var(--vanilla)', outline:'none' },
  fieldLabel:{ fontSize:10.5, fontWeight:600, letterSpacing:'.07em', textTransform:'uppercase', color:'var(--navy-35)' },
  memIntro:{ fontSize:13, fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy-60)', lineHeight:1.6 },
  memSearch:{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--rs)', background:'var(--vanilla)' },
  memRow:  { display:'flex', alignItems:'flex-start', gap:8, padding:'10px 11px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', background:'var(--vanilla)' },
  forgetBtn:{ fontSize:11, color:'var(--navy-35)', cursor:'pointer', background:'none', border:'none', flexShrink:0, fontStyle:'italic', fontFamily:'var(--serif)', marginTop:2 },
  usageTop:{ display:'flex', gap:22, paddingBottom:18, borderBottom:'1px solid var(--vanilla-border)' },
};

Object.assign(window, { SettingsDrawer });
