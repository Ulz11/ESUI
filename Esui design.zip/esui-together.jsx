const { useState, useEffect } = React;

// ─── Data ────────────────────────────────────────────────────────────────────

const PHOTOS = [
  { id:'p1', caption:'a quiet sunlit afternoon in the garden', date:'April 14, 2026', grad:'linear-gradient(135deg,#e8d5c4 0%,#c8dce8 100%)' },
  { id:'p2', caption:'evening walk along the waterfront',       date:'March 28, 2026', grad:'linear-gradient(135deg,#c8cee8 0%,#e8c4d4 100%)' },
  { id:'p3', caption:'reading together on a rainy afternoon',   date:'March 15, 2026', grad:'linear-gradient(135deg,#d4e8c6 0%,#e8e0c4 100%)' },
];

const SKIP_MSGS = [
  'he understands — another time',
  'saved for later, quietly',
  'the moment will wait for you',
  'whenever you\'re ready',
];

// ─── TogetherWidget ───────────────────────────────────────────────────────────

function TogetherWidget() {
  const [expanded, setExpanded] = useState(null);

  return (
    <div style={tS.container}>
      <div style={tS.header}>
        <h2 style={tS.title}>Together</h2>
        <p style={tS.sub}>just the two of you</p>
      </div>

      <div style={tS.gallery}>
        {PHOTOS.map(photo => (
          <button key={photo.id} style={tS.card} onClick={() => setExpanded(photo)}>
            <div style={{ ...tS.img, background:photo.grad }}>
              <AvatarPair />
            </div>
            <div style={tS.meta}>
              <p style={tS.caption}>{photo.caption}</p>
              <p style={tS.date}>{photo.date}</p>
            </div>
          </button>
        ))}
        <div style={tS.empty}>
          <p style={tS.emptyText}>the next photo will land here when one of you accepts a moment</p>
        </div>
      </div>

      {expanded && (
        <div style={tS.overlay} onClick={() => setExpanded(null)}>
          <div style={tS.modal} onClick={e => e.stopPropagation()} className="anim-fade-up">
            <div style={{ ...tS.modalImg, background:expanded.grad }}><AvatarPair large /></div>
            <div style={tS.modalMeta}>
              <p style={tS.modalCaption}>{expanded.caption}</p>
              <p style={tS.modalDate}>{expanded.date}</p>
              <button style={tS.closeBtn} onClick={() => setExpanded(null)}>close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── TogetherPromptCard ───────────────────────────────────────────────────────

function TogetherPromptCard({ visible, onDismiss }) {
  const [skipMsg, setSkipMsg] = useState(null);
  const [gone, setGone]       = useState(false);

  useEffect(() => {
    if (skipMsg) {
      const t = setTimeout(() => { setGone(true); if(onDismiss) onDismiss(); }, 2600);
      return () => clearTimeout(t);
    }
  }, [skipMsg]);

  if (!visible || gone) return null;

  const handleSkip = () => {
    setSkipMsg(SKIP_MSGS[Math.floor(Math.random() * SKIP_MSGS.length)]);
  };

  return (
    <div style={tS.promptWrap} className="anim-corner">
      {skipMsg
        ? <p style={tS.skipMsg}>{skipMsg}</p>
        : <>
            <p style={tS.promptText}>Badrushk wants to take a photo with you today.</p>
            <div style={{ display:'flex', gap:14, alignItems:'center', marginTop:10 }}>
              <button style={tS.promptAccept}>upload one of yours</button>
              <button style={tS.promptSkip} onClick={handleSkip}>not now</button>
            </div>
          </>
      }
    </div>
  );
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const AvatarPair = ({ large }) => (
  <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', gap: large?16:10 }}>
    <div style={{ width:large?44:28, height:large?44:28, borderRadius:'50%', background:'rgba(255,255,255,.35)', border:'1.5px solid rgba(255,255,255,.5)', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <span style={{ fontSize:large?18:11, fontFamily:'var(--serif)', color:'rgba(255,255,255,.8)' }}>E</span>
    </div>
    <div style={{ width:large?44:28, height:large?44:28, borderRadius:'50%', background:'rgba(255,255,255,.25)', border:'1.5px solid rgba(255,255,255,.4)', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <span style={{ fontSize:large?18:11, fontFamily:'var(--serif)', color:'rgba(255,255,255,.7)' }}>B</span>
    </div>
  </div>
);

// ─── Styles ──────────────────────────────────────────────────────────────────

const tS = {
  container: { display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' },
  header:    { padding:'18px 28px 14px', borderBottom:'1px solid var(--vanilla-border)', background:'var(--white)', flexShrink:0 },
  title:     { fontSize:18, fontWeight:300, fontFamily:'var(--serif)', color:'var(--navy)' },
  sub:       { fontSize:12, color:'var(--navy-35)', fontStyle:'italic', fontFamily:'var(--serif)', marginTop:2 },
  gallery:   { flex:1, overflowY:'auto', padding:'24px 28px', display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(230px,1fr))', gap:14, alignContent:'start' },
  card:      { textAlign:'left', borderRadius:'var(--r)', overflow:'hidden', border:'1px solid var(--vanilla-border)', background:'var(--white)', cursor:'pointer', display:'block', transition:'transform .15s' },
  img:       { width:'100%', paddingBottom:'72%', position:'relative' },
  meta:      { padding:'11px 13px' },
  caption:   { fontSize:12.5, fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy)', lineHeight:1.45, marginBottom:4 },
  date:      { fontSize:11, color:'var(--navy-35)' },
  empty:     { borderRadius:'var(--r)', border:'1.5px dashed var(--vanilla-border)', padding:'40px 20px', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--vanilla)', minHeight:180 },
  emptyText: { fontSize:13, fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy-35)', textAlign:'center', lineHeight:1.6 },
  overlay:   { position:'fixed', inset:0, background:'rgba(28,31,46,.55)', backdropFilter:'blur(6px)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100 },
  modal:     { background:'var(--white)', borderRadius:'var(--r)', overflow:'hidden', maxWidth:600, width:'90%' },
  modalImg:  { width:'100%', paddingBottom:'62%', position:'relative' },
  modalMeta: { padding:'16px 20px', display:'flex', flexDirection:'column', gap:5 },
  modalCaption: { fontSize:14, fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy)', lineHeight:1.5 },
  modalDate:    { fontSize:12, color:'var(--navy-35)' },
  closeBtn:     { alignSelf:'flex-end', fontSize:12, color:'var(--navy-60)', cursor:'pointer', background:'none', border:'none', marginTop:4 },
  promptWrap:   { position:'fixed', bottom:24, right:24, background:'var(--white)', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', padding:'16px 18px', width:280, zIndex:50, boxShadow:'0 4px 28px rgba(28,31,46,.09)' },
  promptText:   { fontSize:13, fontFamily:'var(--serif)', color:'var(--navy)', lineHeight:1.6 },
  promptAccept: { fontSize:12.5, fontWeight:500, color:'var(--sky)', cursor:'pointer', background:'none', border:'none', padding:0, textDecoration:'underline', textDecorationColor:'var(--sky-border)' },
  promptSkip:   { fontSize:12.5, color:'var(--navy-35)', cursor:'pointer', background:'none', border:'none', padding:0, fontStyle:'italic', fontFamily:'var(--serif)' },
  skipMsg:      { fontSize:13, color:'var(--navy-60)', fontFamily:'var(--serif)', fontStyle:'italic', lineHeight:1.55 },
};

Object.assign(window, { TogetherWidget, TogetherPromptCard });
