const { useState, useRef } = React;

// ─── Data ────────────────────────────────────────────────────────────────────

const WORKSPACES = [
  { id:'w1', title:'Epistemology & Philosophy of Mind', subject:'Philosophy', updated_at:'1d ago',  artifacts:3 },
  { id:'w2', title:'Linear Algebra',                   subject:'Mathematics', updated_at:'3d ago',  artifacts:2 },
  { id:'w3', title:'Transformer Architecture',         subject:'ML',          updated_at:'1w ago',  artifacts:4 },
];

const ARTIFACTS = [
  { id:'a1', kind:'cheatsheet',   title:'Epistemology cheatsheet',        mode:'ulzii', ts:'1d ago' },
  { id:'a2', kind:'practice_set', title:'JTB & reliabilism questions',     mode:'ulzii', ts:'2d ago' },
  { id:'a3', kind:'concept_map',  title:'Knowledge theories concept map',  mode:'ulzii', ts:'3d ago' },
];

const KIND = {
  cheatsheet:    { label:'Cheatsheet',     color:'#5b9ab8',  icon:'≡' },
  practice_set:  { label:'Practice Set',   color:'#3e6f54',  icon:'◎' },
  concept_map:   { label:'Concept Map',    color:'#8b6fba',  icon:'◈' },
  knowledge_graph:{ label:'Knowledge Graph',color:'#b5893a', icon:'⬡' },
  simulation:    { label:'Simulation',     color:'#c0534d',  icon:'◷' },
};

const CHEATSHEET = {
  sections: [
    { title:'Definitions', items:[
      { term:'Justified True Belief (JTB)', body:'S knows that p iff (1) p is true, (2) S believes p, (3) S is justified in believing p. The classical tripartite account attributed to Plato\'s Meno.' },
      { term:'Reliabilism', body:'S knows that p iff p is true, S believes p, and the belief is produced by a reliable cognitive process. Goldman\'s externalist response to Gettier (1967).' },
      { term:'Epistemic Internalism', body:'Justification is determined solely by factors internal to and accessible to the cognizer — mental states, evidence, reasons.' },
    ]},
    { title:'Key Results', items:[
      { term:'Gettier (1963)', body:'JTB is insufficient for knowledge. Cases exist where an agent has justified true belief yet clearly lacks knowledge — the truth and justification are causally disconnected.' },
      { term:'The Generality Problem', body:'For reliabilism: any token belief is an instance of infinitely many process-types with varying reliabilities. There is no principled answer to which type is the relevant one.' },
    ]},
    { title:'Pitfalls', items:[
      { term:'Confusing internalism/externalism', body:'Internalism is about what determines justification. Externalism is about what determines knowledge. They cross-cut the JTB/reliabilism debate independently.' },
      { term:'Demon-world objection', body:'A brain-in-a-vat may have perfectly reliable internal processes yet systematically false beliefs. This pressures externalism without vindicating pure internalism.' },
    ]},
  ],
};

const QUESTIONS = [
  { id:'q1', type:'short', q:'Construct a Gettier case that defeats JTB. What does it reveal about the relationship between justification and truth?' },
  { id:'q2', type:'mcq',   q:'Goldman\'s causal theory of knowing is best described as:', opts:['Internalist account of justification','Externalist account requiring belief-fact causal connection','Coherentist theory','Pragmatist account of truth'], correct:1 },
  { id:'q3', type:'short', q:'State the generality problem for reliabilism and explain why it resists easy solution.' },
];

// ─── ExamWidget ───────────────────────────────────────────────────────────────

function ExamWidget() {
  const [view, setView]           = useState('list');
  const [activeWS, setActiveWS]   = useState(null);
  const [activeArt, setActiveArt] = useState(null);
  const [kind, setKind]           = useState('cheatsheet');
  const [generating, setGenerating] = useState(false);

  const generate = () => {
    setGenerating(true);
    setTimeout(() => {
      setGenerating(false);
      setActiveArt(ARTIFACTS[kind === 'practice_set' ? 1 : 0]);
      setView('artifact');
    }, 2000);
  };

  if (view === 'artifact' && activeArt) {
    return <ArtifactView art={activeArt} onBack={() => setView('workspace')} />;
  }

  if (view === 'workspace' && activeWS) {
    return (
      <div style={eS.page}>
        <div style={eS.header}>
          <button style={eS.back} onClick={() => setView('list')}>
            <Chev /> Workspaces
          </button>
          <h2 style={eS.h2}>{activeWS.title}</h2>
          <span style={eS.sub}>{activeWS.subject}</span>
        </div>
        <div style={eS.body}>
          {/* Sources */}
          <div style={eS.section}>
            <h3 style={eS.sLabel}>Sources</h3>
            <div style={eS.dropzone}>
              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" style={{ color:'var(--navy-35)' }}><path d="M11 4v10M7 9l4-5 4 5M4 17h14" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
              <span style={{ fontSize:13, color:'var(--navy-60)', fontFamily:'var(--serif)', fontStyle:'italic' }}>drop files here — PDF, DOCX, MD, TXT</span>
            </div>
          </div>

          {/* Generate */}
          <div style={eS.section}>
            <h3 style={eS.sLabel}>Generate artifact</h3>
            <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:14 }}>
              {Object.entries(KIND).map(([k, meta]) => (
                <button key={k}
                  style={{ ...eS.kindChip, ...(kind===k ? { background:meta.color+'18', color:meta.color, borderColor:meta.color+'50' } : {}) }}
                  onClick={() => setKind(k)}
                >
                  <span>{meta.icon}</span><span>{meta.label}</span>
                </button>
              ))}
            </div>
            <button style={{ ...eS.genBtn, opacity: generating?.7:1 }} onClick={generate} disabled={generating}>
              {generating
                ? <><span style={{ width:12, height:12, border:'2px solid rgba(255,255,255,.3)', borderTopColor:'white', borderRadius:'50%', display:'inline-block', animation:'spin .7s linear infinite', marginRight:8 }} />generating…</>
                : `generate ${KIND[kind].label.toLowerCase()}`
              }
            </button>
          </div>

          {/* Artifacts */}
          <div style={eS.section}>
            <h3 style={eS.sLabel}>Artifacts</h3>
            <div style={{ display:'flex', flexDirection:'column', gap:7 }}>
              {ARTIFACTS.map(a => {
                const meta = KIND[a.kind];
                return (
                  <button key={a.id} style={eS.artRow} onClick={() => { setActiveArt(a); setView('artifact'); }}>
                    <span style={{ fontSize:11, fontWeight:500, padding:'2px 8px', borderRadius:10, background:meta.color+'18', color:meta.color, flexShrink:0 }}>{meta.icon} {meta.label}</span>
                    <span style={{ flex:1, fontSize:13.5, fontFamily:'var(--serif)', color:'var(--navy)', textAlign:'left' }}>{a.title}</span>
                    <span style={{ fontSize:11.5, color:'var(--navy-35)' }}>{a.mode} · {a.ts}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Workspace list
  return (
    <div style={eS.page}>
      <div style={eS.header}>
        <h2 style={eS.h1}>Exam</h2>
        <span style={eS.sub}>compress knowledge into artifacts</span>
      </div>
      <div style={eS.wsList}>
        {WORKSPACES.map(ws => (
          <button key={ws.id} style={eS.wsCard} onClick={() => { setActiveWS(ws); setView('workspace'); }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
              <span style={{ fontSize:15, fontFamily:'var(--serif)', fontWeight:400, color:'var(--navy)', flex:1, textAlign:'left' }}>{ws.title}</span>
              <span style={{ fontSize:11.5, color:'var(--navy-35)', marginLeft:12, flexShrink:0 }}>{ws.updated_at}</span>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <span style={{ fontSize:12, color:'var(--sky)', background:'var(--sky-bg)', padding:'2px 9px', borderRadius:10 }}>{ws.subject}</span>
              <span style={{ fontSize:12, color:'var(--navy-35)' }}>{ws.artifacts} artifacts</span>
            </div>
          </button>
        ))}
        <button style={eS.newWs}>
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M6.5 1.5v10M1.5 6.5h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          new workspace
        </button>
      </div>
    </div>
  );
}

// ─── ArtifactView ─────────────────────────────────────────────────────────────

function ArtifactView({ art, onBack }) {
  const [open, setOpen]     = useState({ 0:true });
  const [qi, setQi]         = useState(0);
  const [answers, setAnswers] = useState({});

  if (art.kind === 'cheatsheet') {
    return (
      <div style={eS.page}>
        <div style={eS.header}>
          <button style={eS.back} onClick={onBack}><Chev /> Workspace</button>
          <h2 style={eS.h2}>{art.title}</h2>
          <span style={{ fontSize:12, color:KIND.cheatsheet.color, background:KIND.cheatsheet.color+'15', padding:'2px 9px', borderRadius:10 }}>Cheatsheet</span>
        </div>
        <div style={{ flex:1, overflowY:'auto', padding:'16px 28px', maxWidth:780 }}>
          {CHEATSHEET.sections.map((sec, si) => (
            <div key={si} style={{ marginBottom:8, border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', overflow:'hidden' }}>
              <button
                style={{ width:'100%', display:'flex', justifyContent:'space-between', alignItems:'center', padding:'11px 16px', background:'var(--vanilla)', cursor:'pointer', border:'none', color:'inherit' }}
                onClick={() => setOpen(p => ({ ...p, [si]:!p[si] }))}
              >
                <span style={{ fontSize:11, fontWeight:600, letterSpacing:'.07em', textTransform:'uppercase', color:'var(--sky)' }}>{sec.title}</span>
                <Chev up={open[si]} />
              </button>
              {open[si] && (
                <div style={{ padding:'4px 16px 14px', display:'flex', flexDirection:'column', gap:14 }}>
                  {sec.items.map((item, ii) => (
                    <div key={ii} style={{ paddingTop:12, borderTop: ii===0?'1px solid var(--vanilla-border)':'none' }}>
                      <strong style={{ display:'block', fontSize:13.5, fontFamily:'var(--serif)', fontWeight:500, color:'var(--navy)', marginBottom:4 }}>{item.term}</strong>
                      <p style={{ fontSize:13.5, fontFamily:'var(--serif)', lineHeight:1.72, color:'var(--navy-60)', fontWeight:300 }}>{item.body}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (art.kind === 'practice_set') {
    const q = QUESTIONS[qi];
    return (
      <div style={eS.page}>
        <div style={eS.header}>
          <button style={eS.back} onClick={onBack}><Chev /> Workspace</button>
          <h2 style={eS.h2}>{art.title}</h2>
          <span style={{ fontSize:12, color:'var(--navy-35)' }}>{qi+1} / {QUESTIONS.length}</span>
        </div>
        <div style={{ flex:1, overflowY:'auto', padding:'44px', maxWidth:680, display:'flex', flexDirection:'column', gap:22 }}>
          <p style={{ fontSize:16, fontFamily:'var(--serif)', lineHeight:1.75, fontWeight:300, color:'var(--navy)' }}>{q.q}</p>
          {q.type === 'mcq'
            ? <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {q.opts.map((opt, oi) => (
                  <button key={oi} style={{ textAlign:'left', padding:'11px 14px', border:`1px solid ${answers[q.id]===oi?'var(--sky)':'var(--vanilla-border)'}`, borderRadius:'var(--r)', background:answers[q.id]===oi?'var(--sky-bg)':'var(--white)', fontSize:14, fontFamily:'var(--serif)', color:'var(--navy)', cursor:'pointer' }}
                    onClick={() => setAnswers(p => ({ ...p, [q.id]:oi }))}
                  >{opt}</button>
                ))}
              </div>
            : <textarea
                value={answers[q.id]||''}
                onChange={e => setAnswers(p => ({ ...p, [q.id]:e.target.value }))}
                placeholder="write your answer…"
                style={{ resize:'none', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', padding:14, fontFamily:'var(--serif)', fontSize:14, lineHeight:1.7, color:'var(--navy)', background:'var(--vanilla)', height:150, outline:'none' }}
              />
          }
          <div style={{ display:'flex', gap:10 }}>
            {qi > 0 && <button style={eS.backBtn2} onClick={() => setQi(p=>p-1)}>← previous</button>}
            <button style={{ ...eS.genBtn, marginLeft:'auto', padding:'8px 22px' }}
              onClick={() => qi < QUESTIONS.length-1 ? setQi(p=>p+1) : null}
            >{qi < QUESTIONS.length-1 ? 'next →' : 'submit'}</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={eS.page}>
      <div style={eS.header}><button style={eS.back} onClick={onBack}><Chev /> Workspace</button><h2 style={eS.h2}>{art.title}</h2></div>
      <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center' }}>
        <p style={{ fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy-60)' }}>concept map viewer — coming soon</p>
      </div>
    </div>
  );
}

const Chev = ({ up }) => (
  <svg width="11" height="11" viewBox="0 0 11 11" fill="none" style={{ transform:up?'rotate(180deg)':'rotate(270deg)', flexShrink:0 }}>
    <path d="M2.5 4.5l3 3 3-3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const eS = {
  page:  { display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' },
  header:{ padding:'18px 28px 14px', borderBottom:'1px solid var(--vanilla-border)', display:'flex', flexDirection:'column', gap:4, background:'var(--white)', flexShrink:0 },
  back:  { display:'inline-flex', alignItems:'center', gap:4, fontSize:12, color:'var(--navy-60)', cursor:'pointer', background:'none', border:'none', marginBottom:2, padding:0 },
  h1:    { fontSize:22, fontWeight:300, fontFamily:'var(--serif)', color:'var(--navy)' },
  h2:    { fontSize:18, fontWeight:400, fontFamily:'var(--serif)', color:'var(--navy)' },
  sub:   { fontSize:13, color:'var(--navy-60)', fontFamily:'var(--serif)', fontStyle:'italic' },
  wsList:{ flex:1, overflowY:'auto', padding:'20px 28px', display:'flex', flexDirection:'column', gap:10 },
  wsCard:{ width:'100%', textAlign:'left', padding:'16px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', background:'var(--white)', cursor:'pointer' },
  newWs: { display:'flex', alignItems:'center', gap:7, padding:'12px 16px', border:'1.5px dashed var(--vanilla-border)', borderRadius:'var(--r)', color:'var(--navy-60)', fontSize:13, cursor:'pointer', background:'none' },
  body:  { flex:1, overflowY:'auto', padding:'20px 28px', display:'flex', flexDirection:'column', gap:22 },
  section:{ display:'flex', flexDirection:'column', gap:9 },
  sLabel:{ fontSize:11, fontWeight:600, letterSpacing:'.08em', textTransform:'uppercase', color:'var(--navy-35)' },
  dropzone:{ border:'1.5px dashed var(--vanilla-border)', borderRadius:'var(--r)', padding:'24px', display:'flex', flexDirection:'column', alignItems:'center', gap:8, background:'var(--vanilla)', cursor:'pointer' },
  kindChip:{ display:'flex', alignItems:'center', gap:5, padding:'5px 11px', borderRadius:'var(--rs)', border:'1px solid var(--vanilla-border)', background:'none', fontSize:12, color:'var(--navy-60)', cursor:'pointer' },
  genBtn:{ padding:'9px 20px', background:'var(--navy)', color:'var(--vanilla)', borderRadius:'var(--rs)', fontSize:13, fontWeight:500, cursor:'pointer', border:'none', alignSelf:'flex-start', display:'flex', alignItems:'center' },
  artRow:{ width:'100%', display:'flex', alignItems:'center', gap:10, padding:'11px 14px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', background:'var(--white)', cursor:'pointer' },
  backBtn2:{ padding:'8px 16px', border:'1px solid var(--vanilla-border)', borderRadius:'var(--rs)', fontSize:13, color:'var(--navy-60)', cursor:'pointer', background:'none' },
};

Object.assign(window, { ExamWidget });
