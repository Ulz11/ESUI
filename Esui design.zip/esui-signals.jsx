const { useState } = React;

// ─── Data ────────────────────────────────────────────────────────────────────

const CATEGORIES = [
  { id:'global',  label:'Global',            color:'#5b9ab8' },
  { id:'tech',    label:'Tech',              color:'#3e6f54' },
  { id:'math',    label:'Mathematics',       color:'#8b6fba' },
  { id:'arabic',  label:'Arabic Philosophy', color:'#b5893a' },
  { id:'chinese', label:'Chinese Philosophy',color:'#c0534d' },
  { id:'research',label:'Research',          color:'#6b7094' },
];

const SIGNALS = [
  {
    id:'s1', cat:'global',
    title:'On the fragility of certainty',
    body:'Taleb\'s antifragility framework suggests that systems which gain from disorder differ fundamentally from those which merely resist it. The implication for epistemology: knowledge itself may be antifragile — benefiting from the encounter with counterexamples.',
    src:'Antifragile — Nassim Nicholas Taleb',
  },
  {
    id:'s2', cat:'tech',
    title:'The interpretability bottleneck',
    body:'Mechanistic interpretability research finds that transformer models develop internal representations that don\'t map cleanly onto human concepts. This challenges the "stochastic parrot" view while raising harder questions about what computational understanding could mean.',
    src:'Anthropic Interpretability Research, 2025',
  },
  {
    id:'s3', cat:'math',
    title:'Gödel and epistemic humility',
    body:'Any sufficiently expressive formal system contains true statements it cannot prove from within. This mirrors epistemic situations where our cognitive tools cannot fully audit themselves — a structural limit, not a failure of effort.',
    src:'Gödel, Escher, Bach — Douglas Hofstadter',
  },
  {
    id:'s4', cat:'arabic',
    title:'Ibn Tufayl and the self-taught mind',
    body:'Hayy ibn Yaqzan imagines a child raised alone who arrives at metaphysical truth through unaided observation. The argument: pure reason, given sufficient time and quiet, reaches the same conclusions as revelation. A radical thesis in 12th-century Andalusia.',
    src:'Hayy ibn Yaqzan — Ibn Tufayl, ~1160 CE',
  },
  {
    id:'s5', cat:'chinese',
    title:'Wang Yangming: knowledge and action are one',
    body:'Zhīxíng héyī holds that genuine knowledge of the good necessarily produces the relevant action. To truly know that something is right is already to be moved toward it. This collapses the fact-value gap — and pressures the spectator theory of mind.',
    src:'Instructions for Practical Living — Wang Yangming, ~1520',
  },
  {
    id:'s6', cat:'research',
    title:'Attention is sparser than we assumed',
    body:'New analysis shows large language models concentrate most attention weight on a small fraction of tokens. Much of the nominal context window is not effectively used. This has implications for efficiency — and for theories of how models encode long-range dependency.',
    src:'arXiv preprint, April 2026',
  },
];

// ─── SignalsWidget ────────────────────────────────────────────────────────────

function SignalsWidget() {
  const [items, setItems]   = useState(SIGNALS.map(s => ({ ...s, dismissed:false, pinned:false })));
  const [savedIds, setSavedIds] = useState([]);
  const [refreshTime]       = useState('refreshed at 12:00 UTC');

  const dismiss = (id) => setItems(p => p.map(s => s.id===id ? { ...s, dismissed:true } : s));
  const pin     = (id) => {
    setSavedIds(p => [...p, id]);
    setTimeout(() => setItems(p => p.map(s => s.id===id ? { ...s, pinned:true } : s)), 300);
  };

  return (
    <div style={sS.container}>
      <div style={sS.header}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
          <h2 style={sS.title}>Signals</h2>
          <span style={sS.cycle}>{refreshTime}</span>
        </div>
      </div>
      <div style={sS.grid}>
        {CATEGORIES.map(cat => {
          const catItems = items.filter(s => s.cat===cat.id && !s.dismissed);
          return (
            <div key={cat.id} style={sS.col}>
              <div style={sS.catHead}>
                <span style={{ width:3, height:13, background:cat.color, borderRadius:2, flexShrink:0, display:'block' }} />
                {cat.label}
              </div>
              {catItems.length === 0
                ? <p style={sS.quiet}>quiet</p>
                : catItems.map(sig => (
                  <SignalCard key={sig.id} sig={sig} color={cat.color}
                    pinned={savedIds.includes(sig.id)}
                    onPin={() => pin(sig.id)}
                    onDismiss={() => dismiss(sig.id)}
                  />
                ))
              }
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SignalCard({ sig, color, pinned, onPin, onDismiss }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      style={{ ...sS.card, opacity:sig.dismissed?.0:1, transform:sig.dismissed?'scale(.97)':'scale(1)', transition:'all .2s ease' }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <span style={{ width:2, background:color+'55', borderRadius:1, flexShrink:0, alignSelf:'stretch', minHeight:36, display:'block' }} />
      <div style={{ flex:1, minWidth:0 }}>
        <p style={sS.cardTitle}>{sig.title}</p>
        <p style={sS.cardBody}>{sig.body}</p>
        <p style={sS.cardSrc}>{sig.src}</p>
        <div style={{ ...sS.actions, opacity:hovered?1:0, transition:'opacity .15s' }}>
          <button style={sS.actBtn}>open ↗</button>
          <button style={{ ...sS.actBtn, color:pinned?color:'inherit' }} onClick={onPin}>
            {pinned ? '✓ saved to vault' : 'save to vault'}
          </button>
          <button style={{ ...sS.actBtn, marginLeft:'auto', color:'var(--navy-35)' }} onClick={onDismiss}>dismiss</button>
        </div>
      </div>
    </div>
  );
}

const sS = {
  container: { display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' },
  header:    { padding:'18px 20px 14px', borderBottom:'1px solid var(--vanilla-border)', background:'var(--white)', flexShrink:0 },
  title:     { fontSize:18, fontWeight:300, fontFamily:'var(--serif)', color:'var(--navy)' },
  cycle:     { fontSize:11.5, color:'var(--navy-35)' },
  grid:      { flex:1, overflowY:'auto', overflowX:'auto', padding:'14px 14px 24px', display:'grid', gridTemplateColumns:'repeat(6, minmax(210px,1fr))', gap:10, alignContent:'start' },
  col:       { display:'flex', flexDirection:'column', gap:8 },
  catHead:   { display:'flex', alignItems:'center', gap:7, fontSize:10.5, fontWeight:600, letterSpacing:'.07em', textTransform:'uppercase', color:'var(--navy-60)', paddingBottom:8, borderBottom:'1px solid var(--vanilla-border)', marginBottom:2 },
  quiet:     { fontSize:12, color:'var(--navy-35)', fontStyle:'italic', fontFamily:'var(--serif)', padding:'8px 0' },
  card:      { background:'var(--white)', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)', padding:'11px 10px', display:'flex', gap:9 },
  cardTitle: { fontSize:12.5, fontWeight:500, fontFamily:'var(--serif)', color:'var(--navy)', lineHeight:1.4, marginBottom:5 },
  cardBody:  { fontSize:12, fontFamily:'var(--serif)', lineHeight:1.65, color:'var(--navy-60)', fontWeight:300, marginBottom:5, textWrap:'pretty' },
  cardSrc:   { fontSize:10.5, color:'var(--navy-35)', fontStyle:'italic', fontFamily:'var(--serif)', marginBottom:6 },
  actions:   { display:'flex', alignItems:'center', gap:10 },
  actBtn:    { fontSize:11, color:'var(--navy-60)', cursor:'pointer', background:'none', border:'none', padding:0 },
};

Object.assign(window, { SignalsWidget });
