const { useState } = React;

function LoginPage({ onLogin }) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); setSent(true); }, 1100);
  };

  return (
    <div style={aS.page}>
      <div style={aS.card} className="anim-fade-up">
        <div style={aS.wordmark}>ESUI</div>
        <p style={aS.tagline}>a private workspace — just the two of you</p>

        {!sent ? (
          <form onSubmit={handleSubmit} style={{ width: '100%' }}>
            <div style={aS.inputWrap}>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="your email"
                style={aS.input}
                autoFocus
              />
            </div>
            <button
              type="submit"
              style={{ ...aS.btn, opacity: loading ? .65 : 1 }}
              disabled={loading}
            >
              {loading ? 'sending…' : 'send magic link'}
            </button>
            <p style={aS.hint}>access is by invitation only</p>
          </form>
        ) : (
          <div style={aS.confirm} className="anim-fade-up">
            <p style={aS.confirmText}>check your email — a link is waiting for you</p>
            <button style={aS.demoBtn} onClick={onLogin}>
              continue without email (demo)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const aS = {
  page: {
    width: '100vw', height: '100vh',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'var(--vanilla)',
  },
  card: {
    width: 360,
    display: 'flex', flexDirection: 'column', alignItems: 'center',
  },
  wordmark: {
    fontFamily: 'var(--serif)',
    fontSize: 34, fontWeight: 400,
    letterSpacing: '.12em',
    color: 'var(--navy)',
    marginBottom: 8,
  },
  tagline: {
    fontSize: 13, color: 'var(--navy-60)',
    fontFamily: 'var(--serif)', fontStyle: 'italic',
    marginBottom: 40, textAlign: 'center', lineHeight: 1.5,
  },
  inputWrap: {
    width: '100%',
    borderBottom: '1px solid var(--vanilla-border)',
    marginBottom: 18, paddingBottom: 8,
  },
  input: {
    width: '100%', fontSize: 15,
    color: 'var(--navy)', background: 'transparent',
  },
  btn: {
    width: '100%', padding: '10px 0',
    background: 'var(--navy)', color: 'var(--vanilla)',
    fontSize: 13, fontWeight: 500, letterSpacing: '.025em',
    borderRadius: 'var(--rs)', cursor: 'pointer',
    transition: 'opacity .15s',
  },
  hint: {
    marginTop: 14, textAlign: 'center',
    fontSize: 12, color: 'var(--navy-35)',
    fontFamily: 'var(--serif)', fontStyle: 'italic',
  },
  confirm: { width: '100%', textAlign: 'center' },
  confirmText: {
    fontSize: 14, color: 'var(--navy-60)',
    fontFamily: 'var(--serif)', fontStyle: 'italic',
    lineHeight: 1.65, marginBottom: 24,
  },
  demoBtn: {
    fontSize: 12, color: 'var(--sky)',
    background: 'none', border: 'none', cursor: 'pointer',
    textDecoration: 'underline',
    textDecorationColor: 'var(--sky-border)',
  },
};

Object.assign(window, { LoginPage });
