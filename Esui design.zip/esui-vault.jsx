const { useState, useEffect, useRef } = React;

// ─── Data ────────────────────────────────────────────────────────────────────

const DOCS = [
  { id:'d1', title:'On Gettier and the limits of propositional knowledge', content_type:'note',     tags:['epistemology','philosophy'],            updated_at:'2h ago',  shared:true,  centrality:.92 },
  { id:'d2', title:'Ibn Rushd\'s reading of Aristotle',                    content_type:'research', tags:['arabic philosophy','aristotle'],        updated_at:'1d ago',  shared:false, centrality:.75 },
  { id:'d3', title:'Zhuangzi and the relativity of perspectives',          content_type:'note',     tags:['chinese philosophy','taoism'],          updated_at:'2d ago',  shared:true,  centrality:.68 },
  { id:'d4', title:'ESUI product notes',                                   content_type:'draft',    tags:['product'],                              updated_at:'3d ago',  shared:true,  centrality:.55 },
  { id:'d5', title:'Reading notes: Phenomenology of Spirit',              content_type:'note',     tags:['hegel','philosophy'],                   updated_at:'5d ago',  shared:false, centrality:.70 },
  { id:'d6', title:'Research: transformer attention mechanisms',          content_type:'research', tags:['ml','transformers'],                    updated_at:'1w ago',  shared:false, centrality:.50 },
  { id:'d7', title:'Journal — on long distance',                          content_type:'journal',  tags:['personal'],                             updated_at:'1w ago',  shared:true,  centrality:.40 },
  { id:'d8', title:'Ibn Tufayl: Hayy ibn Yaqzan notes',                   content_type:'research', tags:['arabic philosophy'],                    updated_at:'2w ago',  shared:false, centrality:.62 },
];

const TYPE_COL = { note:'#5b9ab8', research:'#3e6f54', draft:'#b5893a', journal:'#8b6fba', reference:'#888' };

const GRAPH_NODES = [
  { id:'n1', label:'Epistemology',       type:'note',     cx:.38, cy:.30, w:.9 },
  { id:'n2', label:'Gettier Problem',    type:'note',     cx:.22, cy:.20, w:.65 },
  { id:'n3', label:'Ibn Rushd',          type:'research', cx:.62, cy:.22, w:.72 },
  { id:'n4', label:'Aristotle',          type:'research', cx:.78, cy:.34, w:.80 },
  { id:'n5', label:'Zhuangzi',           type:'note',     cx:.55, cy:.64, w:.62 },
  { id:'n6', label:'ESUI Notes',         type:'draft',    cx:.20, cy:.62, w:.52 },
  { id:'n7', label:'Transformers',       type:'research', cx:.82, cy:.68, w:.50 },
  { id:'n8', label:'Long Distance',      type:'journal',  cx:.40, cy:.80, w:.42 },
  { id:'n9', label:'Hegel',              type:'note',     cx:.14, cy:.44, w:.65 },
  { id:'n10',label:'JTB Theory',         type:'note',     cx:.32, cy:.12, w:.58 },
  { id:'n11',label:'Ibn Tufayl',         type:'research', cx:.68, cy:.50, w:.60 },
];
const GRAPH_EDGES = [
  ['n1','n2'],['n1','n9'],['n1','n10'],['n2','n10'],
  ['n3','n4'],['n3','n1'],['n3','n11'],['n4','n1'],
  ['n5','n1'],['n6','n7'],['n11','n3'],['n8','n5'],
];

// ─── VaultWidget ─────────────────────────────────────────────────────────────

function VaultWidget() {
  const [view, setView]           = useState('list');
  const [query, setQuery]         = useState('');
  const [activeDoc, setActiveDoc] = useState(null);
  const [docMd, setDocMd]         = useState('');
  const [saveStatus, setSaveStatus] = useState('saved');
  const saveTimer = useRef(null);

  const filtered = DOCS.filter(d =>
    !query || d.title.toLowerCase().includes(query.toLowerCase()) || d.tags.some(t => t.includes(query.toLowerCase()))
  );

  const openDoc = (doc) => {
    setActiveDoc(doc);
    setDocMd(`# ${doc.title}\n\n`);
    setView('doc');
    setSaveStatus('saved');
  };

  const onDocChange = (val) => {
    setDocMd(val);
    setSaveStatus('saving…');
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      setSaveStatus('indexing…');
      setTimeout(() => setSaveStatus('saved'), 1100);
    }, 900);
  };

  return (
    <div style={vS.container}>
      {/* Header */}
      <div style={vS.header}>
        <div style={vS.searchRow}>
          <SearchIcon />
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="search your vault" style={vS.searchInput} autoFocus={view === 'list'} />
        </div>
        <div style={vS.tabs}>
          {[['list','List'],['graph','Graph']].map(([id,label]) => (
            <button key={id}
              style={{ ...vS.tab, ...(view===id||view==='doc'&&id==='list' ? vS.tabActive : {}) }}
              onClick={() => { setView(id); setActiveDoc(null); }}
            >{label}</button>
          ))}
          <button style={vS.newBtn} onClick={() => openDoc({ id:'new', title:'Untitled', content_type:'note', tags:[], updated_at:'now', shared:false })}>
            <svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M5.5 1v9M1 5.5h9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>
            new
          </button>
        </div>
      </div>

      {/* List */}
      {(view === 'list') && (
        <div style={vS.list}>
          {filtered.length === 0
            ? <div style={vS.empty}><p style={{ fontFamily:'var(--serif)', fontStyle:'italic', color:'var(--navy-60)' }}>nothing in your vault yet — write the first thing on your mind</p></div>
            : filtered.map(doc => (
              <button key={doc.id} style={vS.docRow} onClick={() => openDoc(doc)}>
                <span style={{ ...vS.typePill, background: TYPE_COL[doc.content_type]+'18', color: TYPE_COL[doc.content_type] }}>{doc.content_type}</span>
                <span style={{ fontSize:13.5, fontFamily:'var(--serif)', color:'var(--navy)', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', textAlign:'left' }}>{doc.title}</span>
                <div style={{ display:'flex', alignItems:'center', gap:7, flexShrink:0 }}>
                  {doc.tags.slice(0,2).map(t => <span key={t} style={vS.tag}>{t}</span>)}
                  {doc.shared && <span style={{ fontSize:11, color:'var(--navy-35)' }} title="shared">↗</span>}
                  <span style={{ fontSize:11.5, color:'var(--navy-35)' }}>{doc.updated_at}</span>
                </div>
              </button>
            ))
          }
        </div>
      )}

      {/* Graph */}
      {view === 'graph' && <VaultGraph />}

      {/* Doc editor */}
      {view === 'doc' && activeDoc && (
        <div style={vS.docEditor}>
          <div style={vS.docBar}>
            <button style={vS.backBtn} onClick={() => setView('list')}>
              <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M8 3L4 6.5l4 3.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
              Vault
            </button>
            <span style={{ ...vS.saveStatus, color: saveStatus === 'saved' ? 'var(--navy-35)' : 'var(--sky)' }}>{saveStatus}</span>
          </div>
          <textarea
            value={docMd}
            onChange={e => onDocChange(e.target.value)}
            style={vS.editor}
            autoFocus
          />
        </div>
      )}
    </div>
  );
}

// ─── VaultGraph ──────────────────────────────────────────────────────────────

function VaultGraph() {
  const canvasRef = useRef(null);
  const nodesRef  = useRef(null);
  const rafRef    = useRef(null);
  const frameRef  = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.offsetWidth;
    const H = canvas.offsetHeight;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);

    nodesRef.current = GRAPH_NODES.map(n => ({
      ...n, px: n.cx * W, py: n.cy * H, vx:0, vy:0,
    }));

    const draw = () => {
      frameRef.current++;
      const nodes = nodesRef.current;
      const cooling = Math.max(.05, 1 - frameRef.current * .004);

      if (frameRef.current < 220) {
        // repulsion
        for (let i = 0; i < nodes.length; i++) {
          nodes[i].vx *= .82;
          nodes[i].vy *= .82;
          for (let j = 0; j < nodes.length; j++) {
            if (i === j) continue;
            const dx = nodes[i].px - nodes[j].px;
            const dy = nodes[i].py - nodes[j].py;
            const d  = Math.sqrt(dx*dx + dy*dy) || 1;
            const f  = (1800 / (d*d)) * cooling;
            nodes[i].vx += dx/d * f;
            nodes[i].vy += dy/d * f;
          }
          // gravity
          nodes[i].vx += (W/2 - nodes[i].px) * .004;
          nodes[i].vy += (H/2 - nodes[i].py) * .004;
        }
        // edge springs
        GRAPH_EDGES.forEach(([aid,bid]) => {
          const a = nodes.find(n=>n.id===aid), b = nodes.find(n=>n.id===bid);
          if (!a||!b) return;
          const dx = b.px-a.px, dy = b.py-a.py;
          const d  = Math.sqrt(dx*dx+dy*dy)||1;
          const f  = (d-90)*.035*cooling;
          a.vx+=dx/d*f; a.vy+=dy/d*f;
          b.vx-=dx/d*f; b.vy-=dy/d*f;
        });
        nodes.forEach(n => {
          n.px = Math.max(50, Math.min(W-50, n.px + n.vx));
          n.py = Math.max(40, Math.min(H-40, n.py + n.vy));
        });
      }

      ctx.clearRect(0, 0, W, H);

      // draw edges
      GRAPH_EDGES.forEach(([aid,bid]) => {
        const a = nodes.find(n=>n.id===aid), b = nodes.find(n=>n.id===bid);
        if (!a||!b) return;
        ctx.beginPath();
        ctx.moveTo(a.px, a.py);
        ctx.lineTo(b.px, b.py);
        ctx.strokeStyle = 'rgba(28,31,46,.08)';
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      // draw nodes
      nodes.forEach(n => {
        const r   = 5 + n.w * 9;
        const col = TYPE_COL[n.type] || '#888';
        ctx.beginPath();
        ctx.arc(n.px, n.py, r, 0, Math.PI*2);
        ctx.fillStyle   = col + '30';
        ctx.fill();
        ctx.strokeStyle = col + 'aa';
        ctx.lineWidth   = 1.2;
        ctx.stroke();

        if (n.w > .65) {
          ctx.font      = '11px Inter, sans-serif';
          ctx.fillStyle = 'rgba(28,31,46,.55)';
          ctx.textAlign = 'center';
          ctx.fillText(n.label, n.px, n.py + r + 14);
        }
      });

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return (
    <div style={{ flex:1, position:'relative', overflow:'hidden' }}>
      <canvas ref={canvasRef} style={{ width:'100%', height:'100%', display:'block' }} />
      <div style={{ position:'absolute', bottom:16, left:20, display:'flex', gap:14, flexWrap:'wrap' }}>
        {Object.entries(TYPE_COL).map(([type, color]) => (
          <span key={type} style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:'var(--navy-60)' }}>
            <span style={{ width:7, height:7, borderRadius:'50%', background:color, display:'inline-block' }} />
            {type}
          </span>
        ))}
      </div>
      <div style={{ position:'absolute', top:16, right:20, fontSize:12, color:'var(--navy-35)', fontFamily:'var(--serif)', fontStyle:'italic' }}>
        her thinking as a constellation
      </div>
    </div>
  );
}

// ─── Icons ───────────────────────────────────────────────────────────────────
const SearchIcon = () => (
  <svg width="15" height="15" viewBox="0 0 15 15" fill="none" style={{ color:'var(--navy-35)', flexShrink:0 }}>
    <circle cx="6.5" cy="6.5" r="4.5" stroke="currentColor" strokeWidth="1.3"/>
    <path d="M10 10L12.5 12.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
  </svg>
);

// ─── Styles ──────────────────────────────────────────────────────────────────
const vS = {
  container:   { display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' },
  header:      { padding:'20px 24px 0', display:'flex', flexDirection:'column', gap:10, borderBottom:'1px solid var(--vanilla-border)', background:'var(--white)' },
  searchRow:   { display:'flex', alignItems:'center', gap:10, padding:'9px 12px', background:'var(--vanilla)', border:'1px solid var(--vanilla-border)', borderRadius:'var(--r)' },
  searchInput: { flex:1, fontSize:14, color:'var(--navy)', fontFamily:'var(--serif)' },
  tabs:        { display:'flex', alignItems:'center', gap:2 },
  tab:         { fontSize:12, fontWeight:500, padding:'7px 12px', color:'var(--navy-60)', borderRadius:'var(--rs) var(--rs) 0 0', cursor:'pointer', border:'1px solid transparent', borderBottom:'none' },
  tabActive:   { color:'var(--navy)', background:'var(--vanilla)', border:'1px solid var(--vanilla-border)', borderBottom:'1px solid var(--vanilla)' },
  newBtn:      { marginLeft:'auto', display:'flex', alignItems:'center', gap:5, fontSize:12, fontWeight:500, color:'var(--navy-60)', padding:'5px 10px', borderRadius:'var(--rs)', border:'1px solid var(--vanilla-border)', background:'var(--vanilla)', cursor:'pointer' },
  list:        { flex:1, overflowY:'auto', padding:'4px 0' },
  empty:       { padding:'60px 24px', textAlign:'center' },
  docRow:      { width:'100%', display:'flex', alignItems:'center', gap:12, padding:'12px 24px', borderBottom:'1px solid var(--vanilla-border)', cursor:'pointer', background:'none', transition:'background .1s' },
  typePill:    { fontSize:10.5, fontWeight:500, letterSpacing:'.04em', padding:'2px 7px', borderRadius:10, flexShrink:0 },
  tag:         { fontSize:11, color:'var(--navy-35)', padding:'1px 6px', border:'1px solid var(--vanilla-border)', borderRadius:10 },
  docEditor:   { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
  docBar:      { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 24px', borderBottom:'1px solid var(--vanilla-border)', background:'var(--white)', flexShrink:0 },
  backBtn:     { display:'flex', alignItems:'center', gap:5, fontSize:12.5, color:'var(--navy-60)', cursor:'pointer', background:'none', border:'none' },
  saveStatus:  { fontSize:12, fontStyle:'italic', fontFamily:'var(--serif)', transition:'color .3s' },
  editor:      { flex:1, resize:'none', border:'none', outline:'none', fontFamily:'var(--serif)', fontSize:15.5, lineHeight:1.85, color:'var(--navy)', background:'var(--vanilla)', padding:'40px 20% 80px' },
};

Object.assign(window, { VaultWidget });
