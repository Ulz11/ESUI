const { useState } = React;

// ─── Nav icons ────────────────────────────────────────────────────────────────

const NAV = [
  { id:'chat', label:'Chat', icon:
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M2 2.5h13v9H9l-3.5 3V11.5H2V2.5z" stroke="currentColor" strokeWidth="1.25" strokeLinejoin="round"/>
    </svg>
  },
  { id:'vault', label:'Vault', icon:
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <rect x="2" y="4" width="13" height="10.5" rx="1.5" stroke="currentColor" strokeWidth="1.25"/>
      <path d="M5.5 4V3a3 3 0 016 0v1" stroke="currentColor" strokeWidth="1.25"/>
      <circle cx="8.5" cy="9.5" r="1.5" stroke="currentColor" strokeWidth="1.1"/>
    </svg>
  },
  { id:'exam', label:'Exam', icon:
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <rect x="3" y="1.5" width="11" height="14" rx="1.5" stroke="currentColor" strokeWidth="1.25"/>
      <path d="M5.5 5.5h6M5.5 8.5h6M5.5 11.5h4" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round"/>
    </svg>
  },
  { id:'signals', label:'Signals', icon:
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <circle cx="8.5" cy="8.5" r="2" stroke="currentColor" strokeWidth="1.15"/>
      <path d="M5.5 5.5a4.5 4.5 0 016 6" stroke="currentColor" strokeWidth="1.15" strokeLinecap="round"/>
      <path d="M3 3a8 8 0 0111 11" stroke="currentColor" strokeWidth="1.15" strokeLinecap="round"/>
    </svg>
  },
  { id:'together', label:'Together', icon:
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M8.5 13.5S2 9.7 2 5.7a3.8 3.8 0 017.5-.7 3.8 3.8 0 017.5.7c0 4-6.5 7.8-6.5 7.8z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/>
    </svg>
  },
];

// ─── AppShell ─────────────────────────────────────────────────────────────────

function AppShell({ mode, setMode }) {
  const [route, setRoute]           = useState('chat');
  const [settingsOpen, setSettings] = useState(false);
  const [theme, setTheme]           = useState('light');
  const [expanded, setExpanded]     = useState(false);
  const [promptOn, setPromptOn]     = useState(true);

  const modeColor  = mode === 'ulzii' ? 'var(--sky)'    : 'var(--forest)';
  const modeBg     = mode === 'ulzii' ? 'var(--sky-bg)' : 'var(--forest-bg)';

  const darkVars = theme === 'dark' ? {
    '--vanilla':        '#1c1f2e',
    '--vanilla-2':      '#242739',
    '--vanilla-border': '#2d3148',
    '--white':          '#21243a',
    '--navy':           '#e8e2d8',
    '--navy-60':        'rgba(232,226,216,.6)',
    '--navy-35':        'rgba(232,226,216,.35)',
    '--navy-15':        'rgba(232,226,216,.15)',
    '--navy-08':        'rgba(232,226,216,.08)',
  } : {};

  return (
    <div style={{ ...shS.root, ...darkVars }}>

      {/* ── Nav rail ── */}
      <nav
        style={{ ...shS.rail, width: expanded ? 168 : 50 }}
        onMouseEnter={() => setExpanded(true)}
        onMouseLeave={() => setExpanded(false)}
      >
        {/* Wordmark */}
        <div style={shS.mark}>
          <span style={{ fontFamily:'var(--serif)', fontWeight:400, letterSpacing:'.12em', fontSize:15, color:'var(--navy)', transition:'opacity .15s' }}>
            {expanded ? 'ESUI' : 'E'}
          </span>
        </div>

        {/* Nav items */}
        <div style={shS.items}>
          {NAV.map(item => {
            const active = route === item.id;
            return (
              <button key={item.id}
                style={{ ...shS.item, justifyContent: expanded?'flex-start':'center', ...(active ? { color:modeColor, background:modeBg } : {}) }}
                onClick={() => setRoute(item.id)}
                title={item.label}
              >
                <span style={{ display:'flex', flexShrink:0, position:'relative' }}>
                  {item.icon}
                  {active && !expanded && (
                    <span style={{ position:'absolute', right:-1, top:-1, width:4, height:4, borderRadius:'50%', background:modeColor }} />
                  )}
                </span>
                {expanded && (
                  <span style={{ marginLeft:10, fontSize:13, fontWeight:active?500:400, whiteSpace:'nowrap', opacity:expanded?1:0, transition:'opacity .1s' }}>
                    {item.label}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom */}
        <div style={{ borderTop:'1px solid var(--vanilla-border)', padding:'7px 5px 4px', flexShrink:0 }}>
          <button
            style={{ ...shS.item, justifyContent:expanded?'flex-start':'center' }}
            onClick={() => setSettings(true)}
            title="Settings"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="8" cy="8" r="2.3" stroke="currentColor" strokeWidth="1.2"/>
              <path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round"/>
            </svg>
            {expanded && <span style={{ marginLeft:10, fontSize:13, whiteSpace:'nowrap' }}>Settings</span>}
          </button>

          <div style={{ display:'flex', justifyContent: expanded?'flex-start':'center', padding:'4px 7px 10px', alignItems:'center', gap:9 }}>
            <div style={{ ...shS.avatar, flexShrink:0 }}>E</div>
            {expanded && (
              <div>
                <p style={{ fontSize:12, fontWeight:500, color:'var(--navy)', lineHeight:1 }}>Esui</p>
                <p style={{ fontSize:10.5, color:'var(--navy-35)', marginTop:2 }}>
                  <span style={{ display:'inline-block', width:6, height:6, borderRadius:'50%', background: mode==='ulzii'?'var(--sky)':'var(--forest)', marginRight:4, verticalAlign:'middle' }} />
                  {mode === 'ulzii' ? 'Ulzii mode' : 'Obama mode'}
                </p>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* ── Main ── */}
      <main style={shS.main}>
        {route === 'chat'     && <ChatWidget    mode={mode} setMode={setMode} />}
        {route === 'vault'    && <VaultWidget   />}
        {route === 'exam'     && <ExamWidget    />}
        {route === 'signals'  && <SignalsWidget />}
        {route === 'together' && <TogetherWidget />}
      </main>

      {/* ── Overlays ── */}
      {settingsOpen && (
        <SettingsDrawer
          onClose={() => setSettings(false)}
          mode={mode} setMode={setMode}
          theme={theme} setTheme={setTheme}
        />
      )}

      {route !== 'together' && route !== 'exam' && promptOn && (
        <TogetherPromptCard visible={true} onDismiss={() => setPromptOn(false)} />
      )}
    </div>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const shS = {
  root: { width:'100vw', height:'100vh', display:'flex', overflow:'hidden', background:'var(--vanilla)', transition:'background .3s' },
  rail: { flexShrink:0, height:'100%', background:'var(--white)', borderRight:'1px solid var(--vanilla-border)', display:'flex', flexDirection:'column', overflow:'hidden', zIndex:10, transition:'width .18s ease' },
  mark: { height:50, display:'flex', alignItems:'center', justifyContent:'center', borderBottom:'1px solid var(--vanilla-border)', flexShrink:0, overflow:'hidden' },
  items:{ flex:1, padding:'7px 5px', display:'flex', flexDirection:'column', gap:2, overflowY:'auto' },
  item: { width:'100%', padding:'8px 7px', display:'flex', alignItems:'center', borderRadius:'var(--r)', color:'var(--navy-60)', cursor:'pointer', border:'none', background:'none', transition:'background .1s, color .1s', overflow:'hidden' },
  avatar:{ width:28, height:28, borderRadius:'50%', background:'var(--sky-bg)', color:'var(--sky)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, fontFamily:'var(--serif)', border:'1px solid var(--sky-border)' },
  main: { flex:1, overflow:'hidden', display:'flex', flexDirection:'column' },
};

Object.assign(window, { AppShell });
