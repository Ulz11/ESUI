const { useState } = React;

function AppV2() {
  const [authed, setAuthed] = useState(false);
  const [mode, setMode]     = useState('ulzii');

  if (!authed) return <LoginPage onLogin={() => setAuthed(true)} />;
  return <AppShellV2 mode={mode} setMode={setMode} />;
}

ReactDOM.createRoot(document.getElementById('root')).render(<AppV2 />);
